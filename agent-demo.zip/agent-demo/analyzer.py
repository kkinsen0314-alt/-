
"""
直播运营数据分析模块
读取邀课记录 Excel，计算漏斗指标、分组统计，输出结构化 JSON 供 Agent 调用。
"""

import pandas as pd
import json
from pathlib import Path
from datetime import datetime


def load_data(filepath: str) -> pd.DataFrame:
    """加载邀课记录 Excel，做基础清洗"""
    df = pd.read_excel(filepath)
    
    # 转换「是/否」列为布尔
    bool_cols = [
        "是否到课", "是否连麦", "是否访问课程商品", "是否领取优惠券",
        "是否发起支付", "是否购买课程", "是否抽奖", "是否中奖",
        "是否观看回放", "是否完课", "是否访问直播卡片"
    ]
    for col in bool_cols:
        if col in df.columns:
            df[col] = df[col].map({"是": True, "否": False})
    
    # 时长为秒数
    def _time_to_seconds(val):
        if pd.isna(val):
            return 0
        parts = str(val).split(":")
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
        return 0
    
    for col in ["直播观看时长", "回放观看时长"]:
        if col in df.columns:
            df[f"{col}_秒"] = df[col].apply(_time_to_seconds)
    
    # 预约时间解析
    if "预约时间" in df.columns:
        df["预约日期"] = pd.to_datetime(df["预约时间"], errors="coerce")
    
    return df


def compute_funnel(df: pd.DataFrame) -> dict:
    """计算核心转化漏斗"""
    total = len(df)
    if total == 0:
        return {"total": 0}
    
    metrics = {
        "总人数": total,
        "新用户数": int((df.get("是否新用户") == "新用户").sum()) if "是否新用户" in df.columns else 0,
    }
    
    # 漏斗各层
    funnel_steps = [
        ("预约", None),                        # 到课 = 从预约到到课的转化
        ("到课", "到课率"),
        ("完课", "完课率"),
        ("访问课程商品", "访问率"),
        ("领取优惠券", "领券率"),
        ("发起支付", "支付发起率"),
        ("购买课程", "购买率"),
        ("观看回放", "回放率"),
    ]
    
    for step, rate_name in funnel_steps:
        col = f"是否{step}" if step != "预约" else None
        if col and col in df.columns:
            count = int(df[col].sum())
            rate = round(count / total * 100, 1)
            metrics[f"{step}人数"] = count
            if rate_name:
                metrics[rate_name] = f"{rate}%"
    
    # 观看时长统计
    if "直播观看时长_秒" in df.columns:
        attended = df[df["是否到课"] == True] if "是否到课" in df.columns else pd.DataFrame()
        if len(attended) > 0:
            metrics["平均观看时长_秒"] = round(attended["直播观看时长_秒"].mean(), 0)
            metrics["中位观看时长_秒"] = round(attended["直播观看时长_秒"].median(), 0)
    
    return metrics


def group_by_inviter(df: pd.DataFrame) -> list[dict]:
    """按邀请人分组统计"""
    if "邀请人" not in df.columns:
        return []
    
    result = []
    for name, group in df.groupby("邀请人"):
        item = {"邀请人": name, "预约人数": len(group)}
        for col, label in [
            ("是否到课", "到课率"), ("是否完课", "完课率"),
            ("是否访问课程商品", "访问率"), ("是否购买课程", "购买率")
        ]:
            if col in group.columns:
                count = group[col].sum()
                rate = round(count / len(group) * 100, 1)
                item[label] = f"{rate}%"
        result.append(item)
    
    return sorted(result, key=lambda x: x["预约人数"], reverse=True)


def group_by_channel(df: pd.DataFrame) -> list[dict]:
    """按线索渠道分组统计"""
    if "线索渠道" not in df.columns:
        return []
    
    result = []
    for name, group in df.groupby("线索渠道"):
        item = {"渠道": name, "人数": len(group)}
        for col, label in [
            ("是否到课", "到课率"), ("是否完课", "完课率"),
            ("是否购买课程", "购买率")
        ]:
            if col in group.columns:
                count = group[col].sum()
                rate = round(count / len(group) * 100, 1)
                item[label] = f"{rate}%"
        result.append(item)
    
    return sorted(result, key=lambda x: x["人数"], reverse=True)


def group_by_session(df: pd.DataFrame) -> list[dict]:
    """按直播场次分组统计"""
    if "直播场次" not in df.columns or "直播标题" not in df.columns:
        return []
    
    # 取每场次的标题
    session_titles = df.groupby("直播场次")["直播标题"].first().to_dict()
    
    result = []
    for session, group in df.groupby("直播场次"):
        item = {
            "场次": int(session),
            "标题": session_titles.get(session, ""),
            "人数": len(group),
        }
        for col, label in [
            ("是否到课", "到课率"), ("是否完课", "完课率"),
            ("是否购买课程", "购买率")
        ]:
            if col in group.columns:
                count = group[col].sum()
                rate = round(count / len(group) * 100, 1)
                item[label] = f"{rate}%"
        result.append(item)
    
    return sorted(result, key=lambda x: x["场次"])


def analyze(filepath: str) -> dict:
    """主入口：读文件 → 全量分析 → 返回结构化结果"""
    df = load_data(filepath)
    
    result = {
        "分析时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "数据来源": Path(filepath).name,
        "数据规模": {"总行数": len(df), "总列数": len(df.columns)},
        "核心漏斗": compute_funnel(df),
        "分邀请人": group_by_inviter(df),
        "分渠道": group_by_channel(df),
        "分场次": group_by_session(df),
    }
    
    return result


def to_markdown_summary(result: dict) -> str:
    """将分析结果转为 Markdown 摘要，方便 LLM 消费"""
    lines = []
    lines.append(f"## 数据分析摘要\n")
    lines.append(f"- 分析时间：{result['分析时间']}")
    lines.append(f"- 数据来源：{result['数据来源']}")
    lines.append(f"- 数据规模：{result['数据规模']['总行数']} 条记录\n")
    
    funnel = result.get("核心漏斗", {})
    lines.append("### 核心漏斗")
    lines.append(f"- 总人数：{funnel.get('总人数', 0)}")
    lines.append(f"- 到课率：{funnel.get('到课率', 'N/A')}")
    lines.append(f"- 完课率：{funnel.get('完课率', 'N/A')}")
    lines.append(f"- 访问商品率：{funnel.get('访问率', 'N/A')}")
    lines.append(f"- 购买率：{funnel.get('购买率', 'N/A')}")
    if "平均观看时长_秒" in funnel:
        lines.append(f"- 平均观看时长：{funnel['平均观看时长_秒']} 秒\n")
    
    # Top 邀请人
    inviters = result.get("分邀请人", [])
    if inviters:
        lines.append("### 邀请人表现 (Top 3)")
        for item in inviters[:3]:
            lines.append(f"- {item['邀请人']}：预约 {item['预约人数']} 人，到课率 {item.get('到课率', 'N/A')}，购买率 {item.get('购买率', 'N/A')}")
    
    # 渠道
    channels = result.get("分渠道", [])
    if channels:
        lines.append("\n### 渠道分布")
        for item in channels[:5]:
            lines.append(f"- {item['渠道']}：{item['人数']} 人，到课率 {item.get('到课率', 'N/A')}")
    
    return "\n".join(lines)


# ===== 命令行入口 =====
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("用法: python analyzer.py <Excel文件路径> [--json | --markdown]")
        print("示例: python analyzer.py data.xlsx --json")
        sys.exit(1)
    
    filepath = sys.argv[1]
    output_format = sys.argv[2] if len(sys.argv) > 2 else "--json"
    
    result = analyze(filepath)
    
    if output_format == "--markdown":
        print(to_markdown_summary(result))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))
