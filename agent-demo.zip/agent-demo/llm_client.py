
"""
LLM 客户端模块
支持 OpenAI 兼容 API（DeepSeek / OpenAI / 本地模型等）
"""

import os
import json
from urllib import request, error


class LLMClient:
    """通用 LLM 调用客户端"""

    def __init__(self, api_key: str = None, base_url: str = None, model: str = None):
        """
        初始化客户端
        - 默认使用 DeepSeek（国内可访问，免费额度）
        - 也支持 OpenAI / 其他 OpenAI 兼容 API
        """
        self.api_key = api_key or os.getenv("LLM_API_KEY", "your-deepseek-api-key")
        self.base_url = (base_url or os.getenv("LLM_BASE_URL", "https://api.deepseek.com")).rstrip("/")
        self.model = model or os.getenv("LLM_MODEL", "deepseek-chat")

    def chat(self, system_prompt: str, user_prompt: str,
             temperature: float = 0.7, max_tokens: int = 2000) -> str:
        """
        发送对话请求，返回模型回复文本
        """
        url = f"{self.base_url}/v1/chat/completions"

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        req = request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
        )

        try:
            with request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result["choices"][0]["message"]["content"]
        except error.HTTPError as e:
            body = e.read().decode("utf-8")
            raise RuntimeError(f"API 调用失败 (HTTP {e.code}): {body}")
        except error.URLError as e:
            raise RuntimeError(f"网络连接失败: {e.reason}")


# ===== 快速测试 =====
if __name__ == "__main__":
    client = LLMClient()
    print(f"模型: {client.model}")
    print(f"端点: {client.base_url}")

    # 简单连通性测试
    try:
        reply = client.chat(
            system_prompt="用一句话回复。",
            user_prompt="请说'API 连接成功'",
            max_tokens=50,
        )
        print(f"回复: {reply}")
    except RuntimeError as e:
        print(f"错误: {e}")
        print("提示: 请设置环境变量 LLM_API_KEY 或直接传入 api_key 参数")
