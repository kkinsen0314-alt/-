﻿# 直播运营数据智能分析 Agent

基于 LLM 的运营数据分析 Agent，实现「Excel 输入 → 数据分析 → Prompt 渲染 → LLM 推理 → Markdown 报告输出」的端到端自动化工作流。

## 架构

```
CSV/Excel 输入
     │
     ▼
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  analyzer   │ ──→ │  Prompt 模板  │ ──→ │  LLM (API)  │
│  Pandas统计  │     │  3套可复用模板  │     │  DeepSeek   │
└─────────────┘     └──────────────┘     └─────────────┘
                                                    │
                                                    ▼
                                             ┌─────────────┐
                                             │ Markdown报告 │
                                             │  自动保存     │
                                             └─────────────┘
```

## 三种分析模式

| 模式 | 用途 | 触发场景 |
|------|------|---------|
| `daily` | 日常运营总结 | 每场直播后自动生成日报 |
| `anomaly` | 异常预警 | 指标偏离阈值时自动告警 |
| `optimization` | 优化建议 | 周期性复盘，输出可落地策略 |

## 快速开始

### 1. 安装依赖

```bash
pip install pandas openpyxl
```

### 2. 设置 API Key

```bash
# 方式一：环境变量（推荐）
set LLM_API_KEY=sk-your-deepseek-key

# 方式二：命令行参数
python agent.py data.xlsx --api-key sk-your-key
```

默认使用 **DeepSeek** API（国内可访问，新用户有免费额度）。也支持任何 OpenAI 兼容 API：

```bash
set LLM_BASE_URL=https://api.openai.com/v1
set LLM_MODEL=gpt-4o-mini
```

### 3. 运行

```bash
# 日常总结
python agent.py 邀课记录导出-2026-08-02.xlsx

# 异常预警
python agent.py 邀课记录导出-2026-08-02.xlsx --mode anomaly

# 优化建议
python agent.py 邀课记录导出-2026-08-02.xlsx --mode optimization

# 全量分析（三种模式依次运行）
python agent.py 邀课记录导出-2026-08-02.xlsx --mode all
```

### 4. 查看报告

报告保存在 `output/` 目录，Markdown 格式，可直接在 VS Code / Typora / 浏览器中查看。

## 项目结构

```
agent-demo/
├── agent.py              # Agent 主控：模式调度 + Pipeline 编排
├── analyzer.py           # 数据分析引擎：Pandas 清洗 + 漏斗计算 + 分组统计
├── llm_client.py         # LLM 客户端：OpenAI 兼容 API 封装
├── prompts/              # Prompt 模板库（可复用）
│   ├── daily_summary.md  #  日常总结：角色 + 格式 + Few-shot
│   ├── anomaly_alert.md  #  异常预警：阈值体系 + 三级告警
│   └── optimization.md   #  优化建议：问题诊断 + 方案 + 量化预期
└── output/               # 生成的报告
```

## Prompt 体系设计

三套 Prompt 采用统一结构：

1. **System Prompt**：角色定义 + 输出要求 + 格式规范
2. **Few-shot 示例**：用真实数据展示期望输出
3. **{analysis_json}** 占位符：Agent 运行时动态注入分析结果

## 技术栈

| 组件 | 技术 |
|------|------|
| 数据处理 | Python + Pandas + openpyxl |
| LLM 调用 | DeepSeek API（OpenAI 兼容） |
| Prompt 管理 | Markdown 模板 + 动态变量注入 |
| 输出格式 | Markdown 报告 + JSON 数据 |

## License

MIT
